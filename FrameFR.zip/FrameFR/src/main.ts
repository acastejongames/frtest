import { Map as MlMap, type GeoJSONSource } from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'
import './style.css'

import { fetchPoint, fetchRoutes, HttpError, type Aircraft, type Route } from './adsb'
import { airlineFromCallsign, airlineFromCode, looksLikeFlight } from './airlines'
import { distanceNm, fmtAlt, fmtSpeed, project, type Units } from './format'
import { iconForAlt, registerIcons } from './icons'
import { findMode, MODES, type MapMode } from './styles'

const SOURCE = 'planes'
const LAYER = 'planes'
const POLL_MS = 5000
const RENDER_MS = 1000
const MAX_EXTRAPOLATE_S = 30

// ── Opciones por URL (sin interfaz) ────────────────────────────────────────
//   ?style=liberty|bright|positron|dark|fiord|3d   ?units=metric   ?ground=1
//   #zoom/lat/lon   (la zona que ves en el mapa es la zona que se rastrea)
const params = new URLSearchParams(location.search)
let mode: MapMode = findMode(params.get('style'))
const units: Units = params.get('units') === 'metric' ? 'metric' : 'aviation'
const showGround = params.get('ground') === '1'

const map = new MlMap({
  container: 'map',
  style: mode.url,
  center: [2.7, 39.6],
  zoom: 7.5,
  pitch: mode.pitch,
  maxPitch: 75,
  hash: true,
  attributionControl: { compact: true },
})

// ── Estado ──────────────────────────────────────────────────────────────────
let fleet = new Map<string, Aircraft>()
const routes = new Map<string, Route | null>() // null = sin datos de ruta
const pendingRoutes = new Set<string>()
let pollAbort: AbortController | null = null
let apiBackoffUntil = 0
let routeBackoffUntil = 0

// ── Capa de aviones ─────────────────────────────────────────────────────────
function ensureLayers(): void {
  registerIcons(map)
  if (!map.getSource(SOURCE)) {
    map.addSource(SOURCE, { type: 'geojson', data: { type: 'FeatureCollection', features: [] } })
  }
  if (!map.getLayer(LAYER)) {
    map.addLayer({
      id: LAYER,
      type: 'symbol',
      source: SOURCE,
      layout: {
        'icon-image': ['get', 'icon'],
        'icon-rotate': ['get', 'rot'],
        'icon-rotation-alignment': 'map',
        'icon-pitch-alignment': 'map',
        'icon-allow-overlap': true,
        'icon-ignore-placement': true,
        'icon-size': ['interpolate', ['linear'], ['zoom'], 4, 0.45, 8, 0.7, 12, 1, 16, 1.3],
        'text-field': ['get', 'label'],
        'text-font': ['Noto Sans Regular'],
        'text-size': 11,
        'text-max-width': 24,
        'text-variable-anchor': ['left', 'right', 'top', 'bottom'],
        'text-radial-offset': 1.3,
        'text-justify': 'auto',
        'text-allow-overlap': false,
        'symbol-sort-key': ['get', 'order'],
      },
      paint: {},
    })
  }
  applyTheme()
  if (mode.id === '3d' && map.getLayer('building-3d')) {
    map.setLayoutProperty('building-3d', 'visibility', 'visible')
  }
}

function applyTheme(): void {
  if (!map.getLayer(LAYER)) return
  map.setPaintProperty(LAYER, 'text-color', mode.dark ? '#f1f5f9' : '#0f172a')
  map.setPaintProperty(LAYER, 'text-halo-color', mode.dark ? 'rgba(8,12,20,0.9)' : 'rgba(255,255,255,0.95)')
  map.setPaintProperty(LAYER, 'text-halo-width', 1.6)
}

// ── Render: posición estimada + etiquetas ───────────────────────────────────
function routeText(a: Aircraft): string {
  const r = routes.get(a.callsign)
  if (r && r.airports.length >= 2) return r.airports.join(' → ')
  if (a.callsign && pendingRoutes.has(a.callsign)) return '… → …'
  return '— → —'
}

function render(): void {
  const src = map.getSource(SOURCE) as GeoJSONSource | undefined
  if (!src) return
  const now = Date.now()
  const features: GeoJSON.Feature<GeoJSON.Point>[] = []
  for (const a of fleet.values()) {
    if (a.onGround && !showGround) continue
    const dt = Math.min(MAX_EXTRAPOLATE_S, (now - a.ts) / 1000)
    const [lat, lon] = a.onGround ? [a.lat, a.lon] : project(a.lat, a.lon, a.track, a.gs, dt)
    const route = routes.get(a.callsign)
    const airline = airlineFromCallsign(a.callsign) ?? airlineFromCode(route?.airline)
    const ident = a.callsign || a.reg || a.hex.toUpperCase()
    const label = [
      [ident, airline].filter(Boolean).join(' · '),
      [a.type || '—', fmtAlt(a.alt, a.onGround, units), fmtSpeed(a.gs, units)].join(' · '),
      routeText(a),
    ].join('\n')
    features.push({
      type: 'Feature',
      geometry: { type: 'Point', coordinates: [lon, lat] },
      properties: {
        id: a.hex,
        icon: iconForAlt(a.alt, a.onGround),
        rot: a.track ?? 0,
        label,
        order: -(a.alt ?? 0),
      },
    })
  }
  src.setData({ type: 'FeatureCollection', features })
}

// ── Datos: aviones y rutas ──────────────────────────────────────────────────
async function refresh(): Promise<void> {
  if (document.hidden || Date.now() < apiBackoffUntil) return
  const c = map.getCenter()
  const b = map.getBounds()
  const radius = Math.max(
    distanceNm(c.lat, c.lng, b.getNorth(), b.getEast()),
    distanceNm(c.lat, c.lng, b.getSouth(), b.getWest()),
  )
  pollAbort?.abort()
  const ctl = (pollAbort = new AbortController())
  try {
    const list = await fetchPoint(c.lat, c.lng, radius, ctl.signal)
    fleet = new Map(list.map((a) => [a.hex, a]))
    render()
    void lookupRoutes(list)
  } catch (e) {
    if ((e as Error).name === 'AbortError') return
    if (e instanceof HttpError && e.status === 429) apiBackoffUntil = Date.now() + 30_000
    console.warn('adsb.lol:', e)
  }
}

async function lookupRoutes(list: Aircraft[]): Promise<void> {
  if (Date.now() < routeBackoffUntil) return
  const seen = new Set<string>()
  const need = list.filter((a) => {
    const cs = a.callsign
    if (!cs || !looksLikeFlight(cs) || routes.has(cs) || pendingRoutes.has(cs) || seen.has(cs)) return false
    if (a.onGround && !showGround) return false
    seen.add(cs)
    return true
  })
  for (let i = 0; i < need.length; i += 100) {
    const batch = need.slice(i, i + 100)
    batch.forEach((a) => pendingRoutes.add(a.callsign))
    try {
      const found = await fetchRoutes(batch.map((a) => ({ callsign: a.callsign, lat: a.lat, lon: a.lon })))
      for (const a of batch) routes.set(a.callsign, found.get(a.callsign) ?? null)
    } catch (e) {
      routeBackoffUntil = Date.now() + 30_000
      console.warn('adsb.lol routeset:', e)
    } finally {
      batch.forEach((a) => pendingRoutes.delete(a.callsign))
    }
    render()
  }
}

// ── Modos de mapa (teclado 1-6 o S; también ?style=) ───────────────────────
function setMode(next: MapMode): void {
  if (next.id === mode.id) return
  const sameStyle = next.url === mode.url
  mode = next
  const q = new URLSearchParams(location.search)
  q.set('style', mode.id)
  history.replaceState(null, '', `${location.pathname}?${q}${location.hash}`)
  map.easeTo({ pitch: mode.pitch, duration: 800 })
  if (sameStyle) {
    ensureLayers()
  } else {
    map.setStyle(mode.url)
  }
}

window.addEventListener('keydown', (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey) return
  if (e.key === 's' || e.key === 'S') {
    setMode(MODES[(MODES.findIndex((m) => m.id === mode.id) + 1) % MODES.length])
  } else if (/^[1-9]$/.test(e.key) && MODES[Number(e.key) - 1]) {
    setMode(MODES[Number(e.key) - 1])
  }
})

// ── Arranque ────────────────────────────────────────────────────────────────
map.on('style.load', () => {
  ensureLayers()
  render()
})
map.once('load', () => void refresh())

let moveTimer: number | undefined
map.on('moveend', () => {
  window.clearTimeout(moveTimer)
  moveTimer = window.setTimeout(() => void refresh(), 400)
})

setInterval(() => void refresh(), POLL_MS)
setInterval(render, RENDER_MS)
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) void refresh()
})
