export type Units = 'aviation' | 'metric'

export function fmtAlt(alt: number | null, onGround: boolean, units: Units): string {
  if (onGround) return 'tierra'
  if (alt === null) return '—'
  if (units === 'metric') return `${Math.round((alt * 0.3048) / 10) * 10} m`
  return `${Math.round(alt / 100) * 100} ft`
}

export function fmtSpeed(gs: number | null, units: Units): string {
  if (gs === null) return '—'
  if (units === 'metric') return `${Math.round(gs * 1.852)} km/h`
  return `${Math.round(gs)} kt`
}

/** Distancia en millas náuticas entre dos puntos (haversine). */
export function distanceNm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3440.065
  const rad = Math.PI / 180
  const dLat = (lat2 - lat1) * rad
  const dLon = (lon2 - lon1) * rad
  const a =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2
  return 2 * R * Math.asin(Math.sqrt(a))
}

/** Posición estimada tras dt segundos siguiendo rumbo y velocidad. */
export function project(
  lat: number,
  lon: number,
  trackDeg: number | null,
  gsKt: number | null,
  dtSec: number,
): [number, number] {
  if (trackDeg === null || gsKt === null || gsKt <= 0 || dtSec <= 0) return [lat, lon]
  const nm = (gsKt * dtSec) / 3600
  const t = (trackDeg * Math.PI) / 180
  const dLat = (Math.cos(t) * nm) / 60
  const dLon = (Math.sin(t) * nm) / (60 * Math.max(0.01, Math.cos((lat * Math.PI) / 180)))
  return [lat + dLat, lon + dLon]
}
