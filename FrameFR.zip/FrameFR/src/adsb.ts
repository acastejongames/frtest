const API = 'https://api.adsb.lol'

export interface Aircraft {
  hex: string
  callsign: string
  reg: string
  /** Código ICAO del tipo, p. ej. B738 */
  type: string
  /** Altitud barométrica en pies (null si se desconoce). */
  alt: number | null
  onGround: boolean
  /** Velocidad sobre el suelo en nudos. */
  gs: number | null
  /** Rumbo en grados. */
  track: number | null
  lat: number
  lon: number
  /** Instante (ms) al que corresponde la posición. */
  ts: number
}

interface RawAircraft {
  hex?: string
  flight?: string
  r?: string
  t?: string
  alt_baro?: number | 'ground'
  gs?: number
  track?: number
  lat?: number
  lon?: number
  seen_pos?: number
}

/** Aviones alrededor de un punto. adsb.lol admite hasta 250 NM de radio. */
export async function fetchPoint(
  lat: number,
  lon: number,
  radiusNm: number,
  signal?: AbortSignal,
): Promise<Aircraft[]> {
  const r = Math.max(1, Math.min(250, Math.ceil(radiusNm)))
  const url = `${API}/v2/point/${lat.toFixed(4)}/${lon.toFixed(4)}/${r}`
  const res = await fetch(url, { signal })
  if (!res.ok) throw new HttpError(res.status)
  const data = (await res.json()) as { ac?: RawAircraft[]; now?: number }
  const now = Date.now()
  const out: Aircraft[] = []
  for (const a of data.ac ?? []) {
    if (typeof a.lat !== 'number' || typeof a.lon !== 'number' || !a.hex) continue
    out.push({
      hex: a.hex,
      callsign: (a.flight ?? '').trim(),
      reg: a.r ?? '',
      type: a.t ?? '',
      alt: typeof a.alt_baro === 'number' ? a.alt_baro : null,
      onGround: a.alt_baro === 'ground',
      gs: typeof a.gs === 'number' ? a.gs : null,
      track: typeof a.track === 'number' ? a.track : null,
      lat: a.lat,
      lon: a.lon,
      ts: now - (a.seen_pos ?? 0) * 1000,
    })
  }
  return out
}

export class HttpError extends Error {
  constructor(public status: number) {
    super(`HTTP ${status}`)
  }
}

export interface Route {
  /** Aeropuertos del vuelo en orden (IATA, o ICAO si no hay IATA). */
  airports: string[]
  /** Código de aerolínea devuelto por la API, si lo hay. */
  airline?: string
}

interface RawRoute {
  callsign?: string
  airline_code?: string
  airport_codes?: string
  _airport_codes_iata?: string
  _airports?: { iata?: string; icao?: string }[]
}

/** Origen y destino por indicativo (adsb.lol routeset). */
export async function fetchRoutes(
  planes: { callsign: string; lat: number; lon: number }[],
  signal?: AbortSignal,
): Promise<Map<string, Route>> {
  const out = new Map<string, Route>()
  if (planes.length === 0) return out
  const res = await fetch(`${API}/api/0/routeset`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({
      planes: planes.map((p) => ({ callsign: p.callsign, lat: p.lat, lng: p.lon })),
    }),
    signal,
  })
  if (!res.ok) throw new HttpError(res.status)
  const data: unknown = await res.json()
  const list: RawRoute[] = Array.isArray(data) ? (data as RawRoute[]) : []
  for (const r of list) {
    if (!r.callsign) continue
    let airports: string[] = []
    if (r._airports?.length) {
      airports = r._airports.map((a) => a.iata || a.icao || '').filter(Boolean)
    }
    if (airports.length < 2) {
      const raw = r._airport_codes_iata || r.airport_codes || ''
      airports = raw && raw.toLowerCase() !== 'unknown' ? raw.split('-').filter(Boolean) : []
    }
    out.set(r.callsign, { airports, airline: r.airline_code })
  }
  return out
}
