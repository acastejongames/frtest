// Todos los modos de OpenFreeMap (https://openfreemap.org)
const BASE = 'https://tiles.openfreemap.org/styles'

export interface MapMode {
  id: string
  url: string
  /** Fondo oscuro: etiquetas claras. */
  dark: boolean
  /** Vista inclinada con edificios en 3D. */
  pitch: number
}

export const MODES: MapMode[] = [
  { id: 'liberty', url: `${BASE}/liberty`, dark: false, pitch: 0 },
  { id: 'bright', url: `${BASE}/bright`, dark: false, pitch: 0 },
  { id: 'positron', url: `${BASE}/positron`, dark: false, pitch: 0 },
  { id: 'dark', url: `${BASE}/dark`, dark: true, pitch: 0 },
  { id: 'fiord', url: `${BASE}/fiord`, dark: true, pitch: 0 },
  // OpenFreeMap "3D" = estilo Liberty con edificios extruidos
  { id: '3d', url: `${BASE}/liberty`, dark: false, pitch: 60 },
]

export function findMode(id: string | null): MapMode {
  return MODES.find((m) => m.id === id) ?? MODES[0]
}
