// Prefijo ICAO de 3 letras del indicativo -> aerolínea. Lista parcial: si el
// prefijo no está aquí se muestra el propio código.
const AIRLINES: Record<string, string> = {
  RYR: 'Ryanair', RUK: 'Ryanair UK', VLG: 'Vueling', IBE: 'Iberia', IBS: 'Iberia Express',
  AEA: 'Air Europa', ANE: 'Air Nostrum', VOE: 'Volotea', BIB: 'Binter', EVE: 'Evelop',
  PUE: 'Plus Ultra', WFL: 'World2fly', SWT: 'Swiftair', EZY: 'easyJet', EJU: 'easyJet Europe',
  EZS: 'easyJet Switzerland', BAW: 'British Airways', EXS: 'Jet2', TOM: 'TUI Airways',
  TUI: 'TUI Airways', JAF: 'TUI fly Belgium', TFL: 'TUI fly Netherlands', DLH: 'Lufthansa',
  EWG: 'Eurowings', EWE: 'Eurowings Europe', DLA: 'Discover Airlines', CFG: 'Condor',
  GEC: 'Lufthansa Cargo', SWR: 'Swiss', EDW: 'Edelweiss', AUA: 'Austrian', BEL: 'Brussels Airlines',
  AFR: 'Air France', TVF: 'Transavia France', TRA: 'Transavia', KLM: 'KLM', LGL: 'Luxair',
  CLX: 'Cargolux', ITY: 'ITA Airways', NOS: 'Neos', TAP: 'TAP Air Portugal', EIN: 'Aer Lingus',
  ICE: 'Icelandair', SAS: 'SAS', FIN: 'Finnair', NAX: 'Norwegian', NSZ: 'Norwegian',
  WZZ: 'Wizz Air', WMT: 'Wizz Air Malta', WUK: 'Wizz Air UK', LOT: 'LOT Polish', CSA: 'Czech Airlines',
  TVS: 'Smartwings', ROT: 'Tarom', AEE: 'Aegean', SEH: 'Sky Express', BTI: 'airBaltic',
  AMC: 'Air Malta', CAI: 'Corendon', SXS: 'SunExpress', THY: 'Turkish Airlines', PGT: 'Pegasus',
  LDM: 'Lauda Europe', LOG: 'Loganair', ABR: 'ASL Airlines', BOX: 'AeroLogic',
  RAM: 'Royal Air Maroc', DAH: 'Air Algérie', TAR: 'Tunisair', MSR: 'EgyptAir', ELY: 'El Al',
  UAE: 'Emirates', QTR: 'Qatar Airways', ETD: 'Etihad', SVA: 'Saudia', ETH: 'Ethiopian',
  KQA: 'Kenya Airways', SAA: 'South African', AIC: 'Air India', SIA: 'Singapore Airlines',
  CPA: 'Cathay Pacific', ANA: 'All Nippon', JAL: 'Japan Airlines', KAL: 'Korean Air',
  QFA: 'Qantas', ANZ: 'Air New Zealand',
  AAL: 'American', DAL: 'Delta', UAL: 'United', SWA: 'Southwest', JBU: 'JetBlue', ASA: 'Alaska',
  ACA: 'Air Canada', WJA: 'WestJet', TSC: 'Air Transat', AVA: 'Avianca', LAN: 'LATAM',
  TAM: 'LATAM Brasil', GLO: 'Gol', AZU: 'Azul', AMX: 'Aeroméxico', CMP: 'Copa',
  FDX: 'FedEx', UPS: 'UPS', DHK: 'DHL', DHX: 'DHL',
}

const FLIGHT_RE = /^([A-Z]{3})\d/

/** Aerolínea a partir del indicativo; null si no parece un vuelo comercial. */
export function airlineFromCallsign(callsign: string): string | null {
  const m = FLIGHT_RE.exec(callsign)
  if (!m) return null
  return AIRLINES[m[1]] ?? m[1]
}

export function airlineFromCode(code: string | undefined): string | null {
  if (!code) return null
  return AIRLINES[code] ?? code
}

/** ¿Tiene pinta de número de vuelo (y no de matrícula)? */
export function looksLikeFlight(callsign: string): boolean {
  return /^[A-Z]{2,3}\d[A-Z0-9]*$/.test(callsign)
}
