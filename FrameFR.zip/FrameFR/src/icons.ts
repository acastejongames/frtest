import type { Map as MlMap } from 'maplibre-gl'

// Color según la altitud (pies): bajo = naranja, alto = violeta.
export const ALT_STEPS: { min: number; color: string }[] = [
  { min: 0, color: '#f97316' },
  { min: 5000, color: '#facc15' },
  { min: 10000, color: '#4ade80' },
  { min: 20000, color: '#22d3ee' },
  { min: 30000, color: '#3b82f6' },
  { min: 38000, color: '#a855f7' },
]

export const GROUND_ICON = 'plane-ground'

export function iconForAlt(alt: number | null, onGround: boolean): string {
  if (onGround) return GROUND_ICON
  const a = alt ?? 0
  let idx = 0
  for (let i = 0; i < ALT_STEPS.length; i++) if (a >= ALT_STEPS[i].min) idx = i
  return `plane-${idx}`
}

const SIZE = 64

function drawPlane(color: string): ImageData {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = SIZE
  const ctx = canvas.getContext('2d')!
  const p = new Path2D(
    'M32 3c2 0 3 5 3 11v10l23 14v5L35 36v14l7 5v4l-10-2-10 2v-4l7-5V36L6 43v-5l23-14V14c0-6 1-11 3-11z',
  )
  ctx.lineJoin = 'round'
  ctx.lineWidth = 4
  ctx.strokeStyle = 'rgba(8, 12, 20, 0.85)'
  ctx.stroke(p)
  ctx.fillStyle = color
  ctx.fill(p)
  return ctx.getImageData(0, 0, SIZE, SIZE)
}

/** Registra los iconos en el mapa (hay que repetirlo tras cada cambio de estilo). */
export function registerIcons(map: MlMap): void {
  ALT_STEPS.forEach((s, i) => {
    const name = `plane-${i}`
    if (!map.hasImage(name)) map.addImage(name, drawPlane(s.color), { pixelRatio: 2 })
  })
  if (!map.hasImage(GROUND_ICON)) map.addImage(GROUND_ICON, drawPlane('#94a3b8'), { pixelRatio: 2 })
}
