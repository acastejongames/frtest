import { defineConfig } from 'vite'

// Se publica en https://acastejongames.github.io/FrameFR/
export default defineConfig({
  base: '/FrameFR/',
  build: { target: 'es2022', chunkSizeWarningLimit: 1500 },
})
