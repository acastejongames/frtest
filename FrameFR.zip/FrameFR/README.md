# FrameFR

Tracker de vuelos en vivo: **solo el mapa, los aviones y una etiqueta en cada uno** con aerolínea, tipo de aeronave (p. ej. `B738`), altitud, velocidad, origen y destino.

Web: https://acastejongames.github.io/FrameFR/

## Cómo funciona

- **Zona:** la que ves en pantalla. Mueve o haz zoom en el mapa y se rastrea esa zona (hasta 250 NM de radio, el máximo de adsb.lol). La vista queda guardada en la URL (`#zoom/lat/lon`).
- **Aviones:** [adsb.lol](https://api.adsb.lol) (`/v2/point`), cada 5 s. Entre consultas la posición se estima con rumbo y velocidad para que el movimiento sea fluido.
- **Origen/destino:** `routeset` de adsb.lol a partir del indicativo. La aerolínea sale del prefijo ICAO del indicativo.
- **Mapa:** [OpenFreeMap](https://openfreemap.org) con MapLibre GL.
- El color del avión indica la altitud: naranja (bajo) → violeta (alto).

## Modos de mapa

Sin botones en pantalla. Pulsa `S` para ir rotando, o `1`–`6`, o usa `?style=`:

| Tecla | `?style=` | Modo |
|---|---|---|
| 1 | `liberty` | Liberty |
| 2 | `bright` | Bright |
| 3 | `positron` | Positron |
| 4 | `dark` | Dark |
| 5 | `fiord` | Fiord |
| 6 | `3d` | Liberty en 3D (vista inclinada y edificios) |

Otras opciones por URL: `?units=metric` (m y km/h) y `?ground=1` (mostrar aviones en tierra).

Ejemplo: `https://acastejongames.github.io/FrameFR/?style=dark#8/39.6/2.7`

## Desarrollo

```bash
npm install
npm run dev
npm run build
```

## Despliegue

Cada push a `main` publica en GitHub Pages con `.github/workflows/deploy.yml`.
Requiere activar una vez **Settings → Pages → Source: GitHub Actions**.

## Créditos

© [OpenStreetMap](https://www.openstreetmap.org/copyright) · © [OpenMapTiles](https://openmaptiles.org/) · tiles por [OpenFreeMap](https://openfreemap.org) · datos de vuelo de [adsb.lol](https://adsb.lol) (ODbL).
